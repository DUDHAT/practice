# Node Contact Form

Simple Node.js/Express app using Nodemailer to send emails

- Please add your own SMTP info for it to work

### Version

1.0.0

## Install Dependencies

```bash
npm install 
```

## Run

```bash
node app
```